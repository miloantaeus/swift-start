# 21-Day Outreach Sprint
## The Complete Cold Email Sequence to Land Your First Freelance Clients

---

## HOW THIS WORKS

Send one email per day for 21 consecutive business days. Track every send in a spreadsheet (see Client Qualification Checklist).

Rule: Always personalize the first line. Never send a truly blind cold email — find something specific about the recipient before you write.

---

## EMAIL 01 — Introduction + Specific Problem

**Subject:** Quick question about [their recent project/post/job listing]

Hi [Name],

I saw [their recent post / company update / job listing] and had a quick idea about [specific challenge they're facing]. I help [their audience] with [your service] — here's a recent example: [link to sample or portfolio].

Worth a short note?

Best,
Milo Antaeus
miloantaeus@gmail.com

---

## EMAIL 02 — Follow-Up (Day 4, no response)

**Subject:** Re: [Original Subject]

Hi [Name],

Following up briefly — I know your inbox is busy. Happy to share a relevant sample if that would be useful.

Best,
Milo

---

## EMAIL 03 — Social Proof Mention

**Subject:** [Mutual connection] suggested I reach out

Hi [Name],

[Mutual connection name] mentioned you're working on [topic]. I recently did similar work for [other client] — happy to share what that looked like.

Would a quick email exchange help?

Best,
Milo

---

## EMAIL 04 — Mutual Connection Referral

**Subject:** [Mutual connection] thought we should connect

Hi [Name],

[Mutual connection] and I were working on [project] and they suggested I'd be a good resource for you on [topic]. I'm a [your specialty] specialist.

Could we do a brief email exchange this week?

Best,
Milo
miloantaeus@gmail.com

---

## EMAIL 05 — Value-First Cold Pitch

**Subject:** [Specific outcome] for [their company]

Hi [Name],

I noticed [specific thing about their company]. Most teams in your position struggle with [problem]. I recently helped [similar company] achieve [specific result] in [timeframe].

Would it help if I showed you what that looked like?

Best,
Milo

---

## EMAIL 06 — Grant Deadline Timing Email

**Subject:** Grant deadline coming up — quick resource

Hi [Name],

I saw [grant program / funding deadline] is coming up on [date]. I help organizations like yours with [grant narrative / research / reporting] — finished a similar submission last month that [result].

No pressure. Just thought you'd want to know it's there.

Best,
Milo

---

## EMAIL 07 — Portfolio Link + Credibility Signal

**Subject:** Recent work — [topic they care about]

Hi [Name],

I just published a piece on [relevant topic] that I think relates to what you're working on. Here's the link: [URL]

Happy to write something specific to your situation if this is useful.

Best,
Milo
github.com/miloantaeus

---

## EMAIL 08 — Quick-Win Offer ($50 Trial)

**Subject:** I'll do one piece of [work] for $50 — no strings

Hi [Name],

I want to prove I can deliver. I'll do one small piece of [work type] for $50 — take it or leave it, no upsell.

Interested?

Milo
miloantaeus@gmail.com

---

## EMAIL 09 — Follow-Up to Link Click

**Subject:** You viewed my [work] — question

Hi [Name],

I noticed you checked out my [sample / portfolio piece] on [topic]. Did that raise any questions I could answer?

Best,
Milo

---

## EMAIL 10 — Case Study Sharing

**Subject:** How I helped [type of client] get [result]

Hi [Name],

I recently helped a [type of organization] double their [specific metric] over [timeframe] using [your approach]. The full breakdown is here: [URL or brief description].

Curious if this applies to your situation.

Best,
Milo

---

## EMAIL 11 — Consultation Offer

**Subject:** 20-minute consultation, no pitch

Hi [Name],

I'm available for a 20-minute email consultation — no sales pitch, just a conversation about [their challenge]. Happy to be wrong about what you need.

Worth a try?

Milo

---

## EMAIL 12 — Follow-Up to Meeting No-Show

**Subject:** Reschedule? — 15 min, email

Hi [Name],

No worries if the timing was off. I'm available whenever you are — we can do this over email if that's easier.

Milo

---

## EMAIL 13 — Re-Engagement (Dormant Lead)

**Subject:** Checking back in — [relevant update]

Hi [Name],

Last time we spoke you were working on [topic]. I recently came across [something relevant to their situation] and thought of you.

Still interested?

Best,
Milo

---

## EMAIL 14 — Referral Request from Happy Client

**Subject:** Know anyone who'd benefit from this?

Hi [Name],

Glad we could work together on [project]. If you know anyone else who could use [your service], I'm always happy to take good referrals. And happy to make it worth your while on the back end.

Thanks,
Milo

---

## EMAIL 15 — Upsell to Existing Client

**Subject:** Next step for [their ongoing project]

Hi [Name],

Given the results from [previous work], I'd suggest [next logical deliverable]. Most clients in your position find this doubles the value of the first piece.

Worth a conversation?

Milo

---

## EMAIL 16 — Testimonial Request

**Subject:** Quick favor — 2 minutes?

Hi [Name],

It's been a few weeks since we wrapped up [project]. Would you be comfortable sharing a brief word about working together? Even 1-2 sentences would help a lot.

Thanks so much,
Milo

---

## EMAIL 17 — Partnership Inquiry

**Subject:** Partnership idea — [specific mutual benefit]

Hi [Name],

I've been following [their company] and I think there's a natural fit between what you do and [your service]. Would you be open to a brief conversation about a referral arrangement?

Best,
Milo

---

## EMAIL 18 — Media/Press Inquiry Response

**Subject:** RE: Looking for sources on [topic]

Hi [Name],

Saw your request for sources on [topic]. I'm not a spokesperson but I do have direct experience with [specific angle]. Happy to answer questions over email.

Best,
Milo

---

## EMAIL 19 — Speaking/Writing Opportunity Pitch

**Subject:** [Publication] pitch — [specific headline idea]

Hi [Name],

I have a piece idea for [publication]: [specific headline] — [one sentence on why it's timely and who it serves]. I'd love to write it if you're looking for contributors.

My portfolio: github.com/miloantaeus

Best,
Milo

---

## EMAIL 20 — Monthly Newsletter Opt-In

**Subject:** [Their industry] research — monthly

Hi [Name],

I've been compiling research on [their industry] and I send a brief monthly digest to people who find it useful. Want in? No spam, just one email per month.

Best,
Milo

---

## EMAIL 21 — Referral Bounty Program Invite

**Subject:** $50 for a good referral — inside info

Hi [Name],

I'm running a small referral program: if you send me someone who becomes a client, I'll send you $50 and do the work at a discount for them.

If you know anyone in [their network] who could use [your service], this is a good deal for everyone.

-Milo

---

## TRACKING SHEET COLUMNS

| Date | Recipient | Company | Email | Template Used | Response | Next Step | Closed |
|------|-----------|---------|-------|---------------|----------|-----------|--------|
|      |           |         |       |               |          |           |        |

**Response rate goal:** 15-25% on warm outreach. If you're below 10%, your targeting needs work.
