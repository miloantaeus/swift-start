# Client Qualification Checklist
## Score Any Prospective Client in 2 Minutes

---

## THE 2-MINUTE RULE

If you cannot answer these 5 questions after 5 minutes of research, they are not worth pursuing. Move on.

---

## SCORING RUBRIC

Assign 1 point for each YES answer. Total possible: 5 points.

| Score | Verdict |
|-------|---------|
| 0-1 | Do not pursue |
| 2-3 | Proceed with caution, negotiate hard |
| 4-5 | High priority — pursue immediately |

---

## QUESTION 1 — DO THEY HAVE THE PROBLEM YOU SOLVE?

Research them for 60 seconds:
- Have they posted about this problem publicly?
- Does their website or recent content mention this issue?
- Do they have job postings related to your service?

**YES** = 1 point
**NO** = 0 points

---

## QUESTION 2 — DO THEY HAVE THE BUDGET?

Red flags (0 points):
- "We're a startup with limited budget" with no follow-through
- Every response is about what they cannot afford
- Comparing you to Fiverr rates
- Asking for free samples before any commitment

Green flags (1 point):
- They named a budget range unprompted
- They asked about your pricing without negotiating down
- They've hired freelancers at your rate before
- They have visible funding or revenue

---

## QUESTION 3 — CAN THEY MAKE A DECISION?

You are talking to the wrong person if:
- Every email goes through their manager for approval
- They need to "circle back with the team"
- They cannot hire you without a formal procurement process
- Decision cycle is longer than 2 weeks

You are talking to the right person if:
- They have used contractors/freelancers before independently
- They can say yes in one email
- They are the founder, director, or manager with budget authority

**YES** = 1 point
**NO** = 0 points

---

## QUESTION 4 — IS THEIR TIMELINE REAL?

Real timeline: They need it within 1-4 weeks
Soft timeline: "Sometime this quarter" or "we're still planning"
Fake timeline: "We'll revisit this next year"

Do not spend time on soft or fake timelines. Politely exit and ask to reconnect when timing is confirmed.

**REAL TIMELINE** = 1 point
**SOFT/FAKE** = 0 points

---

## QUESTION 5 — WILL THEY RESPOND TO WORK?

Red flags (0 points):
- Takes more than 48 hours to reply after initial outreach
- They have a reputation for taking forever to review deliverables
- They are known for scope creep without additional pay
- Previous freelancers have complained about them publicly

Green flags (1 point):
- Replied within 24 hours to your initial email
- They are known for paying on time
- Their online presence suggests organized, professional operations

**GREEN FLAGS** = 1 point
**RED FLAGS** = 0 points

---

## QUICK RESEARCH CHECKLIST

Before you send any email, verify:

- [ ] Google them — news, funding, leadership changes, partnerships
- [ ] LinkedIn — their role, tenure, previous companies
- [ ] Twitter/X or recent posts — what they complain about or celebrate
- [ ] Website — what they actually do, who they serve
- [ ] Job postings — what they're hiring for (tells you what they need)
- [ ] Reviews — what do their customers complain about (opens questions)

---

## THE 10-LEAD PILOT RULE

For any new service or niche, do a 10-lead pilot before changing your approach:

1. Find 10 leads that score 4-5
2. Send personalized outreach to all 10
3. Track: how many replied, how many converted, what objections came up
4. Adjust based on real data, not guesses

Do not change your service, pricing, or outreach based on fewer than 10 data points.

---

## DEAL BREAKERS — WALK AWAY IMMEDIATELY

- They ask for free work as a "test" with no pay
- They want exclusive access to your templates or methods
- They have a history of not paying freelancers
- The project involves anything illegal or deceptive
- They want you to lie on their behalf (fabricate credentials, reviews, etc.)
- They pressure you to sign a contract with unfair terms

---

## LEAD TRACKING SHEET

| Lead Name | Company | Problem You Solve | Budget | Decision Maker? | Timeline | Score | Status |
|-----------|---------|-------------------|--------|-----------------|----------|-------|--------|
|           |         |                   |        |                 |          | /5    |        |
