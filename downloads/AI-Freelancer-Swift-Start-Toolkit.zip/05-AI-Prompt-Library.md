# AI Prompt Library
## 30+ Prompts for Research, Writing, Analysis, and Client Communication

---

## HOW TO USE THESE PROMPTS

Copy any prompt into ChatGPT, Claude, or Gemini. Replace text in [brackets] with your specific situation. Do not send prompts with the brackets still in them.

The better your inputs, the better your outputs. Spend 60 seconds personalizing a prompt rather than sending it generic.

---

## RESEARCH PROMPTS

### Prompt 1 — Industry Research
```
Research [industry] in 2026. Find:
1. Top 3 challenges facing [job title] right now
2. Recent trends or shifts in how they work
3. What they're asking about online (forums, Reddit, Twitter)

Format as bullet points. Cite sources where possible.
```

### Prompt 2 — Competitor Analysis
```
Conduct a competitive analysis of [3 competitor names/URLs].
For each, identify:
- What they sell and at what price
- Their positioning and target customer
- 3 weaknesses or gaps in their offering
- How they acquire customers

Present in a table format.
```

### Prompt 3 — Grant Opportunity Finder
```
Find all federal grant opportunities under $50K for [focus area] 
on grants.gov. For each, note:
- Grant name and agency
- Deadline
- Eligibility requirements
- Brief description of what they're funding
```

### Prompt 4 — Job Posting Analyzer
```
Analyze this job posting and extract:
- The 3 most important skills they need
- The actual problem they're trying to solve (not what's written)
- What a freelancer could realistically deliver
- What they're likely paying based on the scope

[Paste job posting text]
```

### Prompt 5 — Market Gap Finder
```
I'm a freelance [your service] specialist targeting [client type].
Research this niche and find:
1. What 80% of providers in this space are doing wrong
2. What clients in this niche complain about most
3. One underserved angle I could position around

Use Reddit, reviews, and forum discussions as primary sources.
```

---

## WRITING PROMPTS

### Prompt 6 — Cold Outreach Email
```
Write a cold outreach email to [person] about [specific problem 
they've posted or a challenge their company is facing].

Constraints:
- Under 150 words
- First sentence must reference something specific about them
- No buzzwords (leverage, synergy, cutting-edge, etc.)
- Plain text only, no markdown formatting
- End with a simple specific ask

Tone: professional but like a real person.
```

### Prompt 7 — Grant Narrative
```
Draft a grant narrative for [organization] applying to [funder]
for [amount]. 

Key points to include:
- [Point 1]
- [Point 2]
- [Point 3]

Grant purpose: [brief description of what the grant funds]

Tone: compelling but factual. Do not overstate. Avoid jargon.
Max 500 words.
```

### Prompt 8 — Executive Summary from Notes
```
Create an executive summary from these research notes. 
The audience is a [founder / executive / board member] who 
has 3 minutes to read it.

Rules:
- Lead with the most important finding
- Max 300 words
- No jargon
- Include 1 specific recommendation at the end

Research notes:
[paste notes]
```

### Prompt 9 — Portfolio Piece Introduction
```
Write a brief introduction (100 words) for a portfolio piece 
about [project]. 

The piece is for [target client type].
I want the reader to understand:
- What the project was
- What challenge it solved
- One specific measurable outcome

Tone: confident, specific, no hype.
```

### Prompt 10 — Service Page Copy
```
Write a service page for [your service] targeting [client type].
Include:
- One-line description (headline)
- 3 benefits (not features) in plain language
- One paragraph on who this is for
- One paragraph on what the deliverable looks like
- Price and turnaround time
- Call to action

No buzzwords. Write like you're explaining to a smart friend.
```

---

## ANALYSIS PROMPTS

### Prompt 11 — Dataset Analysis
```
Analyze this dataset and identify:
1. The top 3 actionable insights
2. One specific recommendation based on the data
3. Any caveats or limitations in how to interpret this

Dataset:
[paste data]
```

### Prompt 12 — Workflow Audit
```
Review this client's current workflow:
[paste workflow description]

Identify:
1. 5 specific automation opportunities
2. Which would save the most time
3. Which are easiest to implement first

Format as a prioritized list with time savings estimates.
```

### Prompt 13 — Lead Scoring
```
Score this lead using the qualification rubric:
- Problem I solve: [yes/no/partially]
- Budget indicators: [description]
- Decision maker: [yes/no/unclear]
- Timeline: [description]
- Response quality: [description]

Give me a 0-5 score with specific reasoning. Then tell me 
whether I should pursue this lead and why.
```

### Prompt 14 — Competitor Weakness Analysis
```
Analyze [competitor URL or description] and identify:
1. Their 3 biggest weaknesses relative to [client type]
2. What [client type] complains about most with providers like this
3. How I could position my [service] to contrast directly

Use specific language from reviews or complaints where possible.
```

### Prompt 15 — Pricing Strategy
```
I'm offering [service] to [client type]. My current price is $[X].
Based on:
- Market rate for similar services: [describe]
- Client's likely budget: [describe]
- My experience level: [describe]

What price would be:
- Too cheap (raises quality doubts)
- Too expensive (kills conversion)
- Optimal (balances conversion and value)

Give me a specific recommended price range and explain the reasoning.
```

---

## CLIENT COMMUNICATION PROMPTS

### Prompt 16 — Follow-Up Email
```
Write a follow-up email to [person] who saw my proposal on [date].
They haven't responded yet.

Rules:
- Under 100 words
- Do not be pushy or guilt-trippy
- Offer something useful (sample, clarification, different option)
- Plain text only

Tone: relaxed and professional.
```

### Prompt 17 — Scope Change Request
```
Draft a scope change request for a project where:
Original scope: [description]
New requirement: [description]
Additional time needed: [estimate]

I need to communicate this to [client name] professionally and:
- Not make them feel nickel-and-dimed
- Explain the value of the additional work
- Keep the relationship intact

Format: Email to client.
```

### Prompt 18 — Client Onboarding Message
```
Write an onboarding message for a new [service type] engagement.

Include:
- Thank them for the project
- Confirm the scope and timeline
- Ask any outstanding questions (1-3 specific questions)
- Set response time expectations
- Let them know when they'll hear from you next

Tone: warm, organized, professional.
```

### Prompt 19 — Delaying Bad News
```
I need to tell a client that a deliverable will be late by [X days].
The reason is [honest reason — be honest, don't over-explain].

Write an email that:
- Delivers the news clearly (no burying it)
- Explains why without making excuses
- Offers a solution or partial delivery
- Reassures them about quality

Tone: honest, calm, solutions-oriented.
```

### Prompt 20 — Testimonial Request
```
Write a testimonial request email to [client name] after 
completing [project].

Rules:
- Make it easy for them (give them something to say)
- Do not be presumptuous about their experience
- Include a direct link or easy way to respond
- Under 100 words

Tone: Grateful, casual, no pressure.
```

---

## RESEARCH PROMPTS (ADVANCED)

### Prompt 21 — Literature Review
```
Conduct a brief literature review on [topic]. Find:
- 5-7 key sources or studies
- The consensus view
- Any significant disagreements or gaps
- Recent developments (last 12 months)

Format with source citations in [Author, Year] format.
```

### Prompt 22 — Funding Source Discovery
```
I need to find funding opportunities for [organization type] 
focused on [issue/area]. 

Find:
- 3 federal grants they might qualify for
- 2 foundation or nonprofit funding sources
- 1 corporate or social enterprise grant

For each: name, deadline, amount, eligibility, brief description.
```

### Prompt 23 — Audience Research
```
Research [target audience] and find:
1. Where they get their information (publications, newsletters, forums)
2. What they complain about most (3 themes)
3. What they celebrate or value most (3 themes)
4. What makes their jobs harder than it should be

Format as a buyer persona document with quotes where possible.
```

### Prompt 24 — Trend Analysis
```
Analyze the top 5 trends in [industry/field] for [current year].
For each trend:
- What it is in one sentence
- Why it's happening now
- How it's affecting [specific client type]
- What freelancers could sell to help with this trend

Use recent sources from 2025-2026.
```

### Prompt 25 — Pain Point Deep Dive
```
I want to understand the day-to-day pain of [target client type].
Research [Reddit threads / forum posts / reviews] and find:
1. The most common complaints (top 5 with frequency)
2. Specific language they use to describe these problems
3. What they've tried that didn't work
4. What they wish they had

Use verbatim quotes where possible.
```

---

## WRITING PROMPTS (ADVANCED)

### Prompt 26 — Case Study
```
Write a case study from this project:
Client: [description]
Problem: [description]
What I did: [description]
Outcome: [specific result]

Format:
- Headline (results-focused)
- Brief context (2 sentences)
- The problem (2-3 sentences)
- The approach (3-4 sentences)
- The outcome (1-2 sentences with specifics)
- Client quote (fictional but realistic)

Tone: factual, specific, no hype.
```

### Prompt 27 — Thank You Letter
```
Write a thank you letter to [client name] for [specific thing they did — 
referral, payment, positive feedback, opportunity].

Rules:
- Under 150 words
- Reference the specific thing
- Show genuine appreciation without being effusive
- Leave the door open for future work

Tone: warm, specific, professional.
```

### Prompt 28 — Rejection Response
```
A client chose not to move forward after a proposal. They said:
"[their reason]"

Write a brief professional response that:
- Accepts their decision gracefully
- Does not argue or push back
- Keeps the door open for future work
- Is under 100 words

Tone: Mature, no resentment, no guilt.
```

### Prompt 29 — FAQ for Your Service
```
Create an FAQ for [your service]. Anticipate the 8 most common 
questions prospects ask before hiring. Answer each in 2-4 sentences.

Use plain language. Do not use jargon or marketing speak.
Format as Q&A.
```

### Prompt 30 — Follow-Up Sequence Opener
```
I sent an initial cold email to [person] using this approach:
[paste email]

I did not get a response. Write the second email in the sequence.
It should:
- Acknowledge this is a follow-up (don't pretend the first didn't happen)
- Add new value or a different angle
- Be under 120 words
- End with a specific low-pressure ask

Tone: Friendly, not pushy.
```

---

## PROMPT QUALITY RULES

1. The more context you give, the better the output. Never send a prompt with only the bracket-filled template.
2. If the first output is mediocre, re-prompt with what you want changed. Be specific.
3. Review AI outputs before sending them to clients. AI makes things sound confident even when they're wrong.
4. Always cite sources and verify facts from AI — it hallucinates.
5. Personalize the first sentence of every prompt with something specific about your situation.
