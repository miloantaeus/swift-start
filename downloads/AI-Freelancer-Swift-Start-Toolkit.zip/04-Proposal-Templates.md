# Proposal Templates
## Three Frameworks for Three Price Points

---

## HOW TO USE THESE TEMPLATES

Send a proposal within 2 hours of a prospect responding. Not after, not after a call — within 2 hours.

Format: Plain text email. No attachments yet. Offer to send full documents after agreement.

---

## FRAMEWORK 1 — QUICK WIN ($50-200)

Use when: Prospect has a small, contained need. They want something done fast.

### Email Template

Subject: Your [service name] — ready to start

Hi [Name],

Based on what you shared, here's what I'd deliver:

**Deliverable:** [Exact file or output they will receive]
**Scope:** [What is included]
**Delivery:** [X business days from approval]
**Price:** $[amount]

This is a fixed price for this specific deliverable. If the scope changes significantly, we'll discuss adjustments.

If this works, just reply "yes" and I'll send a payment link.

Best,
Milo Antaeus
miloantaeus@gmail.com

---

### Quick Win Negotiation Scripts

**If they counter-offer:**
"My cost on this is $[your price]. What's driving the budget constraint? Maybe we can narrow the scope to fit."

**If they want more for less:**
"I can do this for $[counter], but it'll mean [fewer sources / shorter document / no revisions]. Which matters less to you?"

**If they want to test you first:**
"I can do a smaller piece for $[half price] as a sample. If you like it, the full project is $[full price]."

---

## FRAMEWORK 2 — STANDARD PROJECT ($200-1000)

Use when: Prospect has a real project with defined scope. They've engaged seriously.

### Email Template

Subject: Proposal: [Project name] for [Their Company]

Hi [Name],

Here's my proposal for [project]:

**What you'll receive:**
- [Deliverable 1 with brief description]
- [Deliverable 2 with brief description]
- [Deliverable 3 if applicable]

**Timeline:** [X business days from start date]

**Scope boundaries:**
This price covers [specific scope]. If requirements change significantly, we'll agree on adjustments before I proceed.

**Revisions:** One round of revisions included. Additional revisions at [rate].

**Investment:** $[amount]

**Next steps:**
1. You reply "yes" to confirm
2. I send a payment link (50% upfront, 50% on delivery)
3. I start work immediately on [date]
4. You'll receive draft by [date]

To move forward, just reply with your approval and I'll send the payment link.

Best,
Milo Antaeus
miloantaeus@gmail.com

---

### Standard Project Negotiation Scripts

**If they say it's over budget:**
"I hear you. The core deliverable without [secondary item] would be $[reduced amount]. Would that still solve the main problem?"

**If they want to phase it:**
"Absolutely — we can split this into Phase 1 ([core deliverable], $[amount], [date]) and Phase 2 ([additional item], $[amount], [date]). That lets you see results before committing to the full scope."

**If they want to talk on the phone:**
"I'm available over email — what questions do you have? Happy to answer anything in writing, and we can do a quick video call if you'd like after you've seen the proposal."

---

## FRAMEWORK 3 — RETAINER RELATIONSHIP ($1000-3000/month)

Use when: Prospect has ongoing needs. They want a reliable resource they can tap regularly.

### Email Template

Subject: Monthly [service] partnership — [Their Company]

Hi [Name],

Based on what you've described, here's what a monthly engagement could look like:

**Ongoing deliverables:**
- [Deliverable 1, X per month]
- [Deliverable 2, X per month]
- [Priority requests, turnaround within 24 hours]

**Hours:** [X hours/month], unused hours do not roll over

**My commitment to you:**
- Responses within [X hours] on business days
- Work delivered on schedule or early
- Direct access to me (no account managers)
- Priority turnaround for urgent requests

**Your commitment:**
- [Monthly fee] per month, invoiced on the 1st
- 30-day cancellation notice

**Trial offer:** 
I'd suggest starting with a one-month trial at $[introductory price] so we can both see if the fit is right before committing long-term.

If this looks promising, let's talk through the details.

Best,
Milo

---

### Retainer Negotiation Scripts

**If they want a lower monthly price:**
"The $[amount] covers [X hours] per month at my standard rate. If you need fewer hours, we can do a lower tier at $[reduced amount] for [reduced hours]. What matters more — hours or certainty of availability?"

**If they want a trial before committing:**
"Absolutely — one month at $[introductory rate] is a good way to test it. If it's working, we can lock in a longer-term rate."

**If they want to pay per project:**
"We can do that, and you're under no obligation. The benefit of the retainer is [priority scheduling, volume discount, relationship continuity]. If per-project works for you, I am available on that basis as well."

---

## WHAT TO INCLUDE IN YOUR PROPOSAL

Never send without:
- Specific deliverable names (not "quality work")
- Exact number of revisions included
- Exact timeline with dates
- Payment structure (50/50 is standard for $500+, 100% upfront for <$200)
- What is NOT included (prevents scope creep)

Never include:
- Vague promises ("I'll do my best")
- Long paragraphs about your process
- List of your qualifications (they already read your profile/portfolio)
- Apologies or hedging language
