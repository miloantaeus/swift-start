# Service Positioning Playbook
## How to Package Your Skills as High-Demand Freelance Services

---

## THE FUNDAMENTAL RULE

Clients do not hire skills. They hire solutions to problems.

Wrong framing: "I'm a data analyst who knows Python and SQL."
Right framing: "I help founders find the 3 numbers in their business that are quietly costing them the most money."

Your job is to translate what you can do into what they get.

---

## STEP 1 — AUDIT YOUR ACTUAL SKILLS

List everything you can actually do. Be specific.

Categories to check:
- Research (web, academic, market, competitive)
- Writing (technical, marketing, grant, reports)
- Data (analysis, visualization, cleaning, automation)
- AI / Automation (prompt engineering, workflow, integrations)
- Communication (presentations, documentation, training)

Do not list things you could learn — only what you can deliver today.

---

## STEP 2 — FIND THE PROBLEMS BEHIND THE SKILLS

For each skill, ask: "What problem does this solve for whom?"

Example chain:
- Skill: Python data analysis
- Problem: Founders don't know which metrics matter
- Client: Early-stage startup founders
- Offer: "I find the 3 numbers hiding in your data that are silently killing your growth"
- Price: $150-300

---

## STEP 3 — CHOOSE YOUR TOP 2 SERVICES

Pick the two services that:
1. You can deliver well today
2. Have clear market demand
3. You can price at $100+

Do not try to offer everything. Two clear services beats five vague ones.

---

## SERVICE PACKAGING FRAMEWORK

### The Quick Win ($50-200)
A contained, discrete deliverable. Good for first clients and testimonials.

Format:
- Name: [Actionable outcome]
- Delivery: [1-3 days]
- Deliverable: [Exact file or format they'll receive]
- Price: [Set a number, never "starting at"]

Example:
- Name: AI Workflow Audit
- Delivery: 48 hours
- Deliverable: A written report with 5 specific automation opportunities
- Price: $99

---

### The Standard Project ($200-1000)
A more complete deliverable with research, writing, or analysis included.

Format:
- Name: [Type of document or outcome]
- Scope: [What you'll research/analyze/write]
- Revisions: [1-2 rounds included]
- Delivery: [5-10 days]
- Price: [Fixed price, never hourly]

Example:
- Name: Competitive Research Report
- Scope: Analysis of 5 competitors across pricing, positioning, and weaknesses
- Revisions: 1 round included
- Delivery: 7 days
- Price: $350

---

### The Retainer ($1000-3000/month)
Ongoing monthly engagement. Best for clients who need regular work.

Format:
- Name: [Ongoing service] — Monthly
- Hours: [X hours per month]
- Deliverables: [List of what they get each month]
- Turnaround: [Response and delivery SLA]
- Price: [Monthly flat fee]

Example:
- Name: Research & Analysis — Monthly
- Hours: 10 hours/month
- Deliverables: 2 research reports + 1 data analysis per month
- Turnaround: Requests responded to within 24 hours
- Price: $1,500/month

---

## PRICING BENCHMARKS

| Service | Quick Win | Standard | Complex |
|---------|-----------|----------|---------|
| Research Report | $50 | $150 | $300+ |
| Grant Proposal | $75 | $250 | $500+ |
| Technical Writing | $40 | $120 | $400+ |
| Data Analysis | $30 | $100 | $300+ |
| AI Automation Audit | $35 | $100 | $250+ |
| Cold Outreach Sequence | $50 | $150 | $300+ |
| Market Research | $60 | $200 | $400+ |
| Competitor Analysis | $75 | $175 | $350+ |

---

## WHERE TO LIST YOUR SERVICES

### Upwork / Fiverr (Marketplaces)
- Create a single focused gig per service
- Use the exact service name from your packaging
- Lead with the outcome, not the process
- Price 20% below your target rate until you have 3+ reviews

### LinkedIn (Direct Outreach)
- Headline: "[Your service] for [specific client type]"
- About section: Problem-first description (3 sentences max)
- Post 3x per week about your specific methodology or findings

### Cold Email (Highest margin)
- Never cold pitch without research first
- Use 21-Day Outreach Sprint for sequence
- Always offer a sample deliverable

---

## WHAT TO SAY ON YOUR PROFILE

Wrong: "I am a highly skilled professional with many years of experience in multiple areas including..."

Right: "I help [specific client type] get [specific outcome] without [their specific pain point]. Recent work: [link to sample]. Most projects delivered in [timeframe]."

---

## OBJECTION HANDLING

### "This is too expensive"
Response: "What budget did you have in mind? I may be able to scope something smaller that still moves the needle."

### "I need to think about it"
Response: "Of course. What specifically are you weighing? I can help address whatever's uncertain."

### "Can you do it cheaper?"
Response: "I price based on the value of the deliverable, not the time it takes me. What I deliver is X. If that's not the right fit, I understand."

### "I found someone cheaper"
Response: "Makes sense. For what it's worth, I price for [specific quality/output]. If that matches what you need, I'm here."
